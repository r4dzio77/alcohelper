using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AlcoHelper.Views.Alcohol
{
    public class AddModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
