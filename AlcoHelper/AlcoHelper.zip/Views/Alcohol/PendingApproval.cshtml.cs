using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AlcoHelper.Views.Alcohol
{
    public class AdminPanelModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
